<?php
/**
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2016 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registred Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

class Cz_Instagramblock extends Module implements WidgetInterface
{
	private $templateFile;
    public function __construct()
    {
        $this->name = 'cz_instagramblock';
        $this->tab = 'front_office_features';
		$this->version = '1.0.0';
        $this->author = 'Codezeel';
		$this->need_instance = 0;
		
		$this->bootstrap = true;
        parent::__construct();
		
        $this->displayName = $this->l('CZ - Instagram Block');
        $this->description = $this->l('Display Instagram pics from an account');
        $this->controllers = array('default');
        
		$this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
        $this->templateFile = 'module:cz_instagramblock/views/templates/hook/cz_instagramblock.tpl';
		
    }

    public function install()
    {
        return parent::install() &&
			Configuration::updateValue('CZ_USERNAME', 'instagram') &&
			Configuration::updateValue('CZ_NB_IMAGE', 8) &&
			Configuration::updateValue('CZ_SIZE', 300) &&
			Configuration::updateValue('CZ_CACHE_DURATION', 'day') &&
			Configuration::updateValue('CZ_IMAGE_FORMAT', 'standard_resolution') &&
			$this->registerHook('displayHome');
    }

    public function getContent()
    {
        return $this->_postProcess() . $this->_getForm();
    }

    private function _postProcess()
    {
        if (Tools::isSubmit('subMOD')) {
            Configuration::updateValue('CZ_USERNAME', Tools::getValue('username'));
            Configuration::updateValue('CZ_NB_IMAGE', intval(Tools::getValue('nb_image')));
            Configuration::updateValue('CZ_IMAGE_FORMAT', Tools::getValue('image_format'));
            Configuration::updateValue('CZ_SIZE', intval(Tools::getValue('size')));
            Configuration::updateValue('CZ_CACHE_DURATION', Tools::getValue('cache_duration'));
            return $this->displayConfirmation($this->l('Settings updated'));
        }
    }

    private function _getForm()
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->languages = $this->context->controller->getLanguages();
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = $this->context->controller->default_form_language;
        $helper->allow_employee_form_lang = $this->context->controller->allow_employee_form_lang;
        $helper->title = $this->displayName;

        $helper->fields_value['username'] = Configuration::get('CZ_USERNAME');
        $helper->fields_value['nb_image'] = Configuration::get('CZ_NB_IMAGE');
        $helper->fields_value['size'] = Configuration::get('CZ_SIZE');
        $helper->fields_value['cache_duration'] = Configuration::get('CZ_CACHE_DURATION');
        $helper->fields_value['image_format'] = Configuration::get('CZ_IMAGE_FORMAT');

        $helper->submit_action = 'subMOD';


        # form
        $this->fields_form[] = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->displayName
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Instagram Username :'),
                        'name' => 'username'
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Image number :'),
                        'name' => 'nb_image',
                        'desc'  => $this->l('You can retry 20 pics maximum')
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Image format :'),
                        'name' => 'image_format',
                        'options'  => array(
                            'query' => array(
                                array('id'   => 'thumbnail', 'name' => $this->l('Thumbnail (150 X 150) - Square crop')),
                                array('id'   => 'low_resolution', 'name' => $this->l('Low resolution (320 x 320)')),
                                array('id'   => 'standard_resolution', 'name' => $this->l('Standard resolution (612 x 612)'))
                            ),
                            'id'    => 'id',
                            'name'  => 'name'
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Resize size in pixel :'),
                        'name' => 'size',
                        'desc'  => $this->l('Your server need the ImageMagick PHP extension to resize pics (0 to desactivate this option)')
                    ),
                    array(
                        'type' => 'select',
                        'name' => 'cache_duration',
                        'label' => $this->l('Refresh :'),
                        'options' => array(
                            'query' => array(
                                array('id' => 'day', 'name' => $this->l('Each day')),
                                array('id' => 'hour', 'name' => $this->l('Each hour'))
                            ),
                            'id' => 'id',
                            'name' => 'name'
                        )
                    )
                ),
                'submit' => array(
                    'title' => $this->l('Save')
                )
            )
        );

        return $helper->generateForm($this->fields_form);
    }

	public function renderWidget($hookName = null, array $configuration = [])
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('cz_instagramblock'))) {
            $this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
        }

        return $this->fetch($this->templateFile, $this->getCacheId('cz_instagramblock'));
    }
	
    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $conf = Configuration::getMultiple(array('CZ_USERNAME', 'CZ_CACHE_DURATION'));
        
		# Gestion du slug du cache
        $cacheIdDate = $conf['CZ_CACHE_DURATION'] == 'day' ? date('Ymd') : date('YmdH');
        $cache_array = array($this->name, $conf['CZ_USERNAME'], $cacheIdDate, (int)$this->context->language->id);
        $cacheId = implode('|', $cache_array);
		
		return array(
             'instagram_pics' => $this->getPics(),
             'username' => $conf['CZ_USERNAME']
        );
		
    }

    public function getPics($all = false) {

        $conf = Configuration::getMultiple(array('CZ_USERNAME', 'CZ_NB_IMAGE', 'CZ_SIZE', 'CZ_IMAGE_FORMAT'));

        $instagram_pics = array();
        $json_url = 'https://www.instagram.com/' . $conf['CZ_USERNAME'] . '/media/';
        $ctx = stream_context_create(array('http' => array('timeout' => 2)));
        $json = Tools::file_get_contents($json_url, false, $ctx);
        $values = Tools::jsonDecode($json);
        if ($values->status != 'ok')
            return array();

        $items = $values->items;

        if(!$all)
            $items = array_slice($items, 0, $conf['CZ_NB_IMAGE']);

        foreach ($items as $item) {

            $image_format = $conf['CZ_IMAGE_FORMAT'] ? $conf['CZ_IMAGE_FORMAT'] : 'standard_resolution';
            $image = $item->images->{$image_format}->url;
            if($conf['CZ_SIZE']) {
                $image = self::imagickResize($image, 'crop', $conf['CZ_SIZE']);
            }
            $instagram_pics[] = array(
                'image' => $image,
                'original_image' => $item->images->standard_resolution->url,
                'caption' => isset($item->caption->text) ? $item->caption->text : '',
                'link' => $item->link
            );
        }
        return $instagram_pics;

    }


    public static function imagickResize($image, $type, $width, $height = null)
    {
        if (!class_exists('Imagick'))
            return $image;

        if (is_null($height)) {
            $height = $width;
        }

        $image_name = md5($image) . '_' . $type . '_' . $width . '_' . $height . '.jpg';
        $image_local = _PS_TMP_IMG_DIR_ . $image_name;

        if (!file_exists($image_local)) {
            copy($image, $image_local);
            if (!file_exists($image_local)) {
                return;
            }
            chmod($image_local, 0755);
            $thumb = new Imagick($image_local);
            if ($type == 'crop') {
                $thumb->cropThumbnailImage($width, $height);
            } elseif ($type == 'resize') {
                $thumb->scaleImage($width, $height, true);
            }
            $thumb->writeImage($image_local);
        }

        $context = Context::getContext();
        return $context->link->getMediaLink(_PS_TMP_IMG_ . $image_name);
    }

}
