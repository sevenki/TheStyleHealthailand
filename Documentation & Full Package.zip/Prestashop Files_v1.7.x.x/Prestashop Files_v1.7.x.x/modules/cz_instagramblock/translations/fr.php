<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockinstagram}prestashop>blockinstagram_c85f95c18f955e6cb9cfc6cb099f1fd7'] = 'Block Instagram';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_6ba576ebb868958014a02224f02fe852'] = 'Affiche les photos Instagram d\'un compte';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres enregistrés';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_4cd587a1fb63a482d93a6ff0fed1d940'] = 'Instagram Username :';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_46dbab4626fb6f4e773fbb527da28fde'] = 'Nombre d\'images :';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_f32b763205b2ee5efcf8e45a7e3349a9'] = 'Taille en pixel des images : ';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_8aa6b19a683137d22f7eaeecbca4fb65'] = 'Refresh :';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_98f5449f725c2be645dc1be794d3b6df'] = 'Chaque jour';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_f826cc3c38088c39b0a05cf87435e08f'] = 'Chaque heure';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockinstagram}prestashop>blockinstagram_5708fc4fc126fb560f3da1782a17970d'] = 'Suivez-nous sur';
